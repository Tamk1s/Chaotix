# EvalBat
"EvalBat" can be used to add floating point support and complex math support to batch files.  It works by allowing you to evaluate (vbscript) expressions in a batch file.
