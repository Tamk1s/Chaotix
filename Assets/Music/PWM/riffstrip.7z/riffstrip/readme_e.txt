RIFFStrip v1.02b
(C) 2003-06 By Marco Pontello

Info: http://mark0.net/soft-riffstrip-e.html
License: freeware!

RIFFStrip is a simple utility for removing the RIFF-WAVE header from,
for ex., a .MP3 file contained in a WAV file. It process all the chunks
chain on the WAV file, and should work correctly with any type of audio
stream: MP3, AC3, etc.

Usage is very simple. Just supply the file name of a WAV file, to obtain
a corresponding file with the added extension ".stripped".

Required System: Win 9x/ME/NT/2K/XP


