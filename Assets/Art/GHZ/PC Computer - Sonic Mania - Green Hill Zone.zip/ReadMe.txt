Extracted using the tools by koolkdev / EyeKey
https://github.com/koolkdev/rsdkv5_extract